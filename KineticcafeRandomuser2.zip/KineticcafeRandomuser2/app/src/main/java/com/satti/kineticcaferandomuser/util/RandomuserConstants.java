package com.satti.kineticcaferandomuser.util;

import java.text.SimpleDateFormat;

/**
 * Created by asadsatti on 16-05-15.
 */
public class RandomuserConstants {

    public static final String RANDOMUSER_URI = "http://api.randomuser.me/"; // API URL
    public static final int REQ_PARAM_PAGE_START_VALUE = 1; // Start page number
    public static final int REQ_PARAM_RESULT_DEFAULT_VALUE = 30; // Result set per request
    public static final int VISIBLE_THRESHOLD = 10; // Load more user threshold
    public static final int TIMEOUT_CONNECTION = 15000;
    public static final int TIMEOUT_READ = 10000;
    public static final String FRAGMENT_ARG_SELECTED_USER = "selected_user"; // Representing the selected user
    private static final String pattern = "MMM/dd/yyyy";
    private static final SimpleDateFormat format = new SimpleDateFormat(pattern);

    public static SimpleDateFormat getDateFormat() {
        return format;
    }

    //
    // Random User API request parameters
    //
    public static final String REQ_PARAM_RESULT = "results"; // number
    public static final String REQ_PARAM_GENDER = "gender"; // female/male
    public static final String REQ_PARAM_SEED = "seed"; // any string
    public static final String REQ_PARAM_NATIONALITIES = "nat"; // nationalities to return us,dk,fr,gb
    public static final String REQ_PARAM_PAGE = "page"; // number for pagination

    // Include/Exclude fields comma delimited: gender, name, location, email, login, registered, dob, phone, cell, id, picture, nat
    public static final String REQ_PARAM_INC = "inc";
    public static final String REQ_PARAM_EXC = "exc";

    // If you only want the data, and don't care for seed, results, page, and version data
    // e.g., results=5&inc=name,gender,nat&noinfo
    public static final String REQ_PARAM_NOINFO = "noinfo";

    // If you want the payload in JSONP, supply a callback using the callback parameter. Only available with JSON formats.
    // e.g., results=5&callback=randomuserdata
    public static final String REQ_PARAM_CALLBACK = "callback";

    public static final String RESP_PARAM_RESULTS = "results";
    public static final String RESP_PARAM_RESULTS_INFO = "info";
    public static final String RESP_PARAM_ERROR = "error";
}

