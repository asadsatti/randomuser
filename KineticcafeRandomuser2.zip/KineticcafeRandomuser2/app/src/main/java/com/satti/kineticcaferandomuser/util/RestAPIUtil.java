package com.satti.kineticcaferandomuser.util;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

/**
 * Created by asadsatti on 16-05-16.
 */
public class RestAPIUtil {

    private static final String TAG = RestAPIUtil.class.getSimpleName();

    /**
     * Create AsyncTask type RestAPIAsync object to make API calls
     *
     * @param url
     * @return
     * @throws MalformedURLException
     * @throws IOException
     */
    public static RestAPIAsync obtainRestAPIAsync(String url)
            throws MalformedURLException, IOException {

        HttpURLConnection connection =
                (HttpURLConnection) (new URL(url))
                        .openConnection();
        connection.setReadTimeout(RandomuserConstants.TIMEOUT_READ);
        connection.setConnectTimeout(RandomuserConstants.TIMEOUT_CONNECTION);
        connection.setDoInput(true);
        RestAPIAsync task = new RestAPIAsync(connection);
        return task;
    }

    /**
     * Create AsyncTask type RestAPIAsync object to download images
     *
     * @param url
     * @return
     * @throws MalformedURLException
     * @throws IOException
     */
    public static RestAPIAsync obtainImageDownloadAsync(String url)
            throws MalformedURLException, IOException {

        HttpURLConnection connection =
                (HttpURLConnection) (new URL(url))
                        .openConnection();
        connection.setReadTimeout(RandomuserConstants.TIMEOUT_READ);
        connection.setConnectTimeout(RandomuserConstants.TIMEOUT_CONNECTION);
        connection.setDoInput(true);
        RestAPIAsync task = new RestAPIAsync(connection);
        task.setImageDownload();
        return task;
    }
}
