package com.satti.randomuser;

import android.app.Activity;
import android.app.ProgressDialog;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.design.widget.CollapsingToolbarLayout;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.satti.randomuser.model.User;
import com.satti.randomuser.util.RandomuserConstants;
import com.satti.randomuser.util.RestAPIAsync;
import com.satti.randomuser.util.RestAPIUtil;

import java.io.IOException;
import java.util.Date;
/**
 * A fragment representing a single User detail screen.
 *
 * This fragment is either contained in a {@link UserListActivity}
 * in two-pane mode (on tablets) or a {@link UserDetailActivity}
 * on handsets.
 *
 */
public class UserDetailFragment extends Fragment implements RestAPIAsync.ProgressCallback, RestAPIAsync.ResponseCallback {

    private static final String TAG = UserDetailFragment.class.getSimpleName();

    private User user;
    ObjectMapper objectMapper = new ObjectMapper();

    private ProgressDialog progressDialog;
    ImageView userImage = null;
    /**
     * Mandatory empty constructor for the fragment manager to instantiate the
     * fragment (e.g. upon screen orientation changes).
     */
    public UserDetailFragment() {
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // The fragment argument representing the selected user that this fragment represents
        if (getArguments().containsKey(RandomuserConstants.FRAGMENT_ARG_SELECTED_USER)) {

            try {
                String user = getArguments().getString(RandomuserConstants.FRAGMENT_ARG_SELECTED_USER);

                this.user = objectMapper.readValue(user, User.class);

                Activity activity = this.getActivity();
                CollapsingToolbarLayout appBarLayout = (CollapsingToolbarLayout) activity.findViewById(R.id.toolbar_layout);

                if (appBarLayout != null) {

                    // Display selected user's name
                    appBarLayout.setTitle(this.user.getName().toString());

                    // Display selected user's picutre
                    User.Picture picture = this.user.getPicture();
                    String pictureUrl = picture.getLarge();
                    userImage = (ImageView) activity.findViewById(R.id.user_photo);
                    if((userImage!=null) && (pictureUrl!=null)) {

                        RestAPIAsync getTask = RestAPIUtil.obtainImageDownloadAsync(pictureUrl);
                        getTask.setResponseCallback(this);
                        getTask.setProgressCallback(this);
                        getTask.execute();

                        // Display progress to the user
                        progressDialog = ProgressDialog.show(getActivity(), "", getString(R.string.mesg_downloading), true);
                    }
                    else {
                        userImage.setVisibility(View.GONE);
                    }
                }
            }
            catch (JsonParseException e) {
                showErrorMesage(getString(R.string.error_parsing_json));
                Log.e(TAG, "JsonParseException: ", e);
            }
            catch (JsonMappingException e) {
                showErrorMesage(getText(R.string.error_parsing_json).toString());
                Log.e(TAG, "JsonMappingException: ", e);
            }
            catch (IOException e) {
                showErrorMesage(getString(R.string.error_io));
                Log.e(TAG, "IOException: ", e);
            }
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.user_detail, container, false);

        if (user != null) {

            // Display selected user's details

            User.Location location = user.getLocation();
            TextView loc = ((TextView) rootView.findViewById(R.id.user_address));
            if((location!=null) && (loc!=null)) {
                loc.setText(getText(R.string.user_address)+": " + location.toString());
            }

            String phone = user.getPhone();
            TextView ph = ((TextView) rootView.findViewById(R.id.user_phone));
            if((phone!=null) && (ph!=null)) {
                ph.setText(getText(R.string.user_phone) + ": " + phone);
            }

            String cell = user.getCell();
            TextView mob = ((TextView) rootView.findViewById(R.id.user_mobile));
            if((cell!=null) && (mob!=null)) {
                mob.setText(getText(R.string.user_mobile) + ": " + cell);
            }

            String dob = user.getDob();
            long d = Long.parseLong(dob);
            Date date=new Date(d*1000);
            TextView db = ((TextView) rootView.findViewById(R.id.user_dob));
            if((date!=null) && (db!=null)) {
                db.setText(getText(R.string.user_dob) + ": " + RandomuserConstants.getDateFormat().format(date));
            }

            String email = user.getEmail();
            TextView eml = ((TextView) rootView.findViewById(R.id.user_email));
            if((email!=null) && (eml!=null)) {
                eml.setText(getText(R.string.user_email) + ": " + email);
            }

            User.Login login = user.getLogin();
            String username = login.getUsername();
            TextView uname = ((TextView) rootView.findViewById(R.id.user_username));
            if((username!=null) && (uname!=null)) {
                uname.setText(getText(R.string.user_username) + ": " + username);
            }

             String nationality = user.getNat();
            TextView nat = ((TextView) rootView.findViewById(R.id.user_nationality));
            if((nationality!=null) && (nat!=null)) {
                nat.setText(getText(R.string.user_nationality) + ": " + nationality);
            }
        }

        return rootView;
    }

    /**
     * Display message
     *
     */
    public void showErrorMesage(String message) {
        Toast.makeText(this.getActivity(), message, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onProgressUpdate(int progress) {

        if (progress >= 0) {
            if (progressDialog != null) {
                progressDialog.dismiss();
                progressDialog = null;
            }
        }
    }

    @Override
    public void onRequestError(Exception error) {
        //Clear progress indicator
        if(progressDialog != null) {
            progressDialog.dismiss();
        }
        showErrorMesage(getString(R.string.error_api));
    }

    @Override
    public void onRequestSuccess(Object resp) {

        //Clear progress indicator
        if(progressDialog != null) {
            progressDialog.dismiss();
        }

        if (resp instanceof Bitmap) {
            userImage.setImageBitmap((Bitmap)resp);
        }

    }
}
