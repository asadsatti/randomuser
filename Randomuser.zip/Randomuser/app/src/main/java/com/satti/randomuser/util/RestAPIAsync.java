package com.satti.randomuser.util;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.util.Log;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.ref.WeakReference;
import java.net.HttpURLConnection;

/**
 * Created by asadsatti on 16-05-16.
 *
 * To Make REST API calls
 *
 */

public class RestAPIAsync extends AsyncTask<Void, Integer, Object> {

    private static final String TAG = RestAPIAsync.class.getSimpleName();

    private HttpURLConnection connection;
    private Exception exception;

    // Activity callbacks. Use WeakReferences to avoid blocking
    // operations causing linked objects to stay in memory
    private WeakReference<ResponseCallback> responseCallback;
    private WeakReference<ProgressCallback> progressCallback;

    private boolean imageDownload = false;

    public interface ResponseCallback {
        public void onRequestSuccess(Object response);
        public void onRequestError(Exception error);
    }

    public interface ProgressCallback {
        public void onProgressUpdate(int progress);
    }

    public RestAPIAsync(HttpURLConnection connection) {

        this.connection = connection;
    }

    public void setResponseCallback(ResponseCallback callback) {
        responseCallback = new WeakReference<ResponseCallback>(callback);
    }

    public void setProgressCallback(ProgressCallback callback) {
        progressCallback = new WeakReference<ProgressCallback>(callback);
    }

    public void setImageDownload() {
        imageDownload = true;
    }

    @Override
    protected Object doInBackground(Void... params) {

        Object response = null;
        try {
            // Call on URLConnection that for Network IO.
            connection.connect();

            // Get response data
            int status = connection.getResponseCode();
            if (status >= 300) {
                String message = connection.getResponseMessage();
                return null;
            }

            InputStream in = connection.getInputStream();
            String encoding = connection.getContentEncoding();
            int contentLength = connection.getContentLength();
            if (encoding == null) {
                encoding = "UTF-8";
            }

            byte[] buffer = new byte[1024];
            int length = contentLength > 0 ? contentLength : 0;
            ByteArrayOutputStream out = new ByteArrayOutputStream(length);
            int downloadedBytes = 0;
            int read;
            while ((read = in.read(buffer)) != -1) {
                downloadedBytes += read;
                publishProgress((downloadedBytes * 100) / contentLength);
                out.write(buffer, 0, read);
            }

            if (imageDownload) {
                byte[] imageData = out.toByteArray();
                response = BitmapFactory.decodeByteArray(imageData, 0, imageData.length);
            }
            else {
                response = new String(out.toByteArray(), encoding);
            }
        }
        catch (Exception e) {
            Log.w(TAG, e);
            exception = e;
        }
        finally {
            if (connection != null) {
                connection.disconnect();
            }
        }

        return response;
    }

    @Override
    protected void onProgressUpdate(Integer... values) {
        // Update progress UI
        if (progressCallback != null
                && progressCallback.get() != null) {
            progressCallback.get().onProgressUpdate(values[0]);
        }
    }

    @Override
    protected void onPostExecute(Object result) {

        if (responseCallback != null
                && responseCallback.get() != null) {

            final ResponseCallback cb = responseCallback.get();

            if ((result instanceof String) ||
                    (result instanceof Bitmap)) {
                cb.onRequestSuccess(result);
            }
            else if (exception != null) {
                cb.onRequestError((Exception) result);
            }
            else {
                cb.onRequestError(new IOException("Unknown Error Contacting Host"));
            }
        }
    }
}
