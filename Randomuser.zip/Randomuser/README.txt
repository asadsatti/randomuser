App using Randomuser API

Smmary:

a) Overall approach

-Each API call loads 30 user records asynchronously

-Used Jackson to convert JSON for a user record to User object

-User objects are stored an ArrayList to be used as a data source for RecyclerView

-RecyclerView to display the list of users because RecyclerView requires to use ViewHolder pattern for better performance

-Chosen to display user name and phone only for each user in the RecyclerView

-Taping user's name converts the User object to JSON string and passes to user detail Activity

-User detail Activity loads user's detail in a fragment

-User object to JSON string conversion is done because I haven’t implemented User as Parcelable which is needed in order to pass to another Activity

-User's photo is also downloaded asynchronously

b) Platform choosen

-Android platform

-Android Studio IDE

-Test device Nexus 4 with Android Lollipop

c) Features implemented

-App loads users from the Randomuser API

-Each page request load 30 users

-Scrolling loads news users if number of users yet to be display is down to 10 for smooth scrolling

-Taping user loads user's profile

-Tested by scrolling be more than 45 pages

d) Improvements needed

-Make UI pretty

-Make phone, email, and address actionable fields

-Use nicer fonts

-Add animations

-Add splash screen

-Taping on the right side of list item doesn't work. It should be fixed

e) Improvement needed to it more robust

-Use Picasso library to download images

-Use retrofit library

-Modify the API request to exclude the parameters from response that are not needed

-Test with two pan devices e.g., tablets

-Implement User class as Parcelable

f) Unzip the project and open and run using Android Studio.
